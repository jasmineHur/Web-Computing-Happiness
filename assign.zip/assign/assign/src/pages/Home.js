import '../assets/css/App.css';

// Main page
function Home() {
  return (
    <div className="app">
      <div className="app-contents"></div>
    </div>
  );
}


export default Home;


